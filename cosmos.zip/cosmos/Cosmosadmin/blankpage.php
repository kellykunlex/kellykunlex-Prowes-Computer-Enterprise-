<?php include "head.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
<!-- Main bar -->
  	<div class="mainbar">
      
	    <!-- Page heading -->
	    <div class="page-head">
        <!-- Page heading -->
	      <h2 class="pull-left">Blank Page
        </h2>


        <!-- Breadcrumb -->
        <div class="bread-crumb pull-right">
          <a href="index.html"><i class="icon-home"></i> Home</a> 
          <!-- Divider -->
          <span class="divider">/</span> 
          <a href="#" class="bread-current">Blank Page </a>
        </div>

        <div class="clearfix"></div>

	    </div>
	    <!-- Page heading ends -->
		
	<!-- Page Content Start Here -->	
		
		
		
		
		<!-- Page Content End Here -->
		<!-- Mainbar ends -->	    	
   <div class="clearfix"></div>

</div>
<!-- Content ends -->
<?php include "notification.php"; ?>
<?php include "script.php"; ?>