<?php include "head.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
<!-- Main bar -->
  	<div class="mainbar">
      
	    <!-- Page heading -->
	    <div class="page-head">
        <!-- Page heading -->
	      <h2 class="pull-left">Introducton Content Settiing image Page 
        </h2>


        <!-- Breadcrumb -->
        <div class="bread-crumb pull-right">
          <a href="dashboard.php"><i class="icon-home"></i> Home</a> 
          <!-- Divider -->
          <span class="divider">/</span> 
          <a href="#" class="bread-current">Introducton Content image Setting Page </a>
        </div>

        <div class="clearfix"></div>

	    </div>
	    <!-- Page heading ends -->
		
	<!-- Page Content Start Here -->	
	<!-- Matter -->

	    <div class="matter">
        <div class="container">

          <div>

            <div class="col-md-12">


              <div class="widget wgreen">
                
                <div class="widget-head">
                  <div class="pull-left">Upload Your Introducton Image</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                <div class="widget-content">
                  <div class="padd">

                    <h6>Input Introducton Image Details</h6>
                    <hr />
                    <!-- Form starts.  -->
                     <form enctype="multipart/form-data" class="form-horizontal" method="post" role="form">
                              
                                <div class="form-group">
                                  <label class="col-lg-2 control-label">Title</label>
                                  <div class="col-lg-8">
                                    <input type="text" name="title" class="form-control" placeholder="Title" required>
                                  </div>
                                </div>
																	  
									  <div class="form-group">
                                  <label class="col-lg-2 control-label">Short Description</label>
                                  <div class="col-lg-8">
                                    <input type="text" name="descrip" class="form-control" placeholder="Title" required>
                                  </div>
                                </div>
                                
								<div class="form-group">
                                  <label class="col-lg-4 control-label">Upload Image</label>
                                  <div class="col-lg-8">
                                    <input type="file" class="form-control" name="image" onChange="readURL(this);"  required>
									<br />
									<img id="blah"  src="img/no_image.jpg" alt="Preview Image Here" height="100" width="150"/>
                                  </div>
                                </div>
								
                                    <hr />
                                <div class="form-group">
                                  <div class="col-lg-offset-1 col-lg-9">
                                    <button type="submit" name="submit" class="btn btn-default">Save Slide Info</button>
                                  </div>
                                </div>
								<?php include "config/connect.php"; ?>
								<?php
                                if (isset($_POST['submit'])) 
								{
								$title= mysqli_real_escape_string($link,$_POST['title']);
								$descrip= mysqli_real_escape_string($link,$_POST['descrip']);
								$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
								$image_name = addslashes($_FILES['image']['name']);
								$image_size = getimagesize($_FILES['image']['tmp_name']);
								move_uploaded_file($_FILES["image"]["tmp_name"], "img/".$_FILES["image"]["name"]);								
								$simage = "img/".$_FILES['image']['name'];
								$insert = mysqli_query($link, "INSERT INTO introcontent (slide_id,title,descrip,slideimage)VALUES('','$title','$descrip','$simage')") or die (mysqli_error($link));
								if(!$insert)
								{
								echo "<script>alert('Settings not Saved.....Please try again later!'); </script>";
								echo '<script>window.location="introimg.php"; </script>';
								}
								else{
								echo "<script>alert('Settings Saved Successfully!!'); </script>";
								echo '<script>window.location="dashboard.php"; </script>';
								}
								}
								?>
                    </form>
                  </div>
                </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
              </div>  

            </div>

          </div>

        </div>
		  </div>
		<!-- Page Content End Here -->
		<!-- Page Content End Here -->
		<div class="col-md-12">
		<div class="widget wviolet">
                <div class="widget-head">
                  <div class="pull-left">All Settings and Tables</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                  <div class="widget-content">

                    <table class="table table-bordered ">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Title</th>
						  <th>Description</th>
                          <th>Image</th>
                          <th>Control</th>
                        </tr>
                      </thead>
                      <tbody>
<?php include "config/connect.php"; ?>  
<?php
$query = mysqli_query($link, "SELECT * FROM introcontent ") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center'>You have no Introduction Content!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$sidm = $row['slide_id'];
$sdm = $row['title'];
$sid = $row['descrip'];
$stid = $row['slideimage'];
?> 
                        <tr>
						   <td><?php echo $sidm ?></td>
						  <td><?php echo $sdm; ?></td>
						   <td><?php echo $sid; ?></td>
						    <td><img src="<?php echo $stid; ?>" width="50" height="50"></td>
                          <td>
                         <a href="#c<?php echo $sidm; ?>"> <button class="btn btn-sm btn-danger" data-target= "#c<?php echo $sidm; ?>" data-toggle="modal" data-toggle="tooltip"><i class="icon-remove"></i> </button>
                          </td>
                        </tr>                                                           
<?php }} ?>  
                      </tbody>
                    </table>


                   </div>

                    <div class="widget-foot">                   
                      <div class="clearfix"></div> 
                    </div>
                	</div>
            		</div>
          			</div>
		    <!-- Mainbar ends -->	    	
   <div class="clearfix"></div>

</div>
<!-- Content ends -->
<?php include "notification.php"; ?>
<?php include "script.php"; ?>
<script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>
<?php
$query = mysqli_query($link, "SELECT * FROM introcontent ") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center'>You have no Introduction Content!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$sidm = $row['slide_id'];
$sdm = $row['title'];
$sid = $row['descrip'];
$stid = $row['slideimage'];
?>  
<div id="c<?php echo $sidm; ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog">
					  <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
                        <h4 class="modal-title">Delete Testimony</h4>
                      </div>
                      <div class="modal-body">
                        <p>Are you Sure you want to delete Introduction Content</p>
                      </div>
                      <div class="modal-footer">
					  <a href="del_intro.php?id=<?php echo $sidm; ?>&&idm=<?php echo $sdm; ?>" class="btn btn-danger"><i class="fa fa-trash"></i>&nbsp;Yes</a>
                        <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">No</button>
                      </div>
                    </div>
					</div>
					</div>
                  </div>
                </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
              </div>  

            </div>
			<?php }} ?>