<?php
include("config/connect.php");
$sidm = $_GET['id'];
$sdm = $_GET['idm'];
$dbn = mysqli_query($link, "DELETE FROM introcontent WHERE slide_id = '$sidm'") or die (mysqli_error($link));
if(!($dbn))
{
echo "<script>alert('Unable to delete records!!!.......please try again later');</script>";
}
else{
echo "<script>alert('Delete Operation is successfully!!!');</script>";
echo "<script>window.location='introimg.php';</script>";
}
?>

		