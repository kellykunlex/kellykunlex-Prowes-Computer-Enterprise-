<?php include "config/connect.php";?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Cosmos Admin</title>
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta name="description" content="">
  <meta name="keywords" content="">
  <meta name="author" content="">

  <!-- Stylesheets -->
  <link href="style/bootstrap.css" rel="stylesheet">
  <link rel="stylesheet" href="style/font-awesome.css">
  <link href="style/style.css" rel="stylesheet">
  
  
  <!-- HTML5 Support for IE -->
  <!--[if lt IE 9]>
  <script src="js/html5shim.js"></script>
  <![endif]-->

  <!-- Favicon -->
  <link rel="shortcut icon" href="img/">
</head>

<body>

<!-- Form area -->
<div class="admin-form">
  <div class="container">

    <div class="row">
      <div class="col-md-12">
        <!-- Widget starts -->
            <div class="widget worange">
              <!-- Widget head -->
              <div class="widget-head">
                <i class="icon-lock"></i> Login 
              </div>

              <div class="widget-content">
                <div class="padd">
                  <!-- Login form -->
                  <form class="form-horizontal"method="post" >
                    <!-- Email -->
                    <div class="form-group">
                      <label class="control-label col-lg-3" for="inputEmail">Email </label>
                      <div class="col-lg-9">
                        <input type="text" name="username" class="form-control" id="inputEmail" placeholder="Email or Username ">
                      </div>
                    </div>
                    <!-- Password -->
                    <div class="form-group">
                      <label class="control-label col-lg-3" for="inputPassword">Password</label>
                      <div class="col-lg-9">
                        <input type="password" name="pass" class="form-control" id="inputPassword" placeholder="Password">
                      </div>
                    </div>
                    <!-- Remember me checkbox and sign in button -->
                    <div class="form-group">
					<div class="col-lg-9 col-lg-offset-3">
                      <div class="checkbox">
                        <label>
                          <input type="checkbox"> Remember me
                        </label>
						</div>
					</div>
					</div>
                        <div class="col-lg-9 col-lg-offset-3">
							<button type="submit" name="submit" class="btn btn-success">Sign in</button>
							<button type="reset" class="btn btn-default">Reset</button>
						</div>
                    <br />
					
					
					 <?php
//include("emailfunc.php");						
if(isset($_POST['submit']))
{						
$username= mysqli_real_escape_string($link, $_POST['username']);
$pass= mysqli_real_escape_string($link, $_POST['pass']);
$encrypt = ($pass);
		
$query = mysqli_query($link, "SELECT * FROM tbl_admin WHERE '$username' IN(email, username) AND password = '$encrypt'") or die(mysqli_error($link));
$row = mysqli_fetch_array($query);
$numberOfRows = mysqli_num_rows($query);																																					
if ($numberOfRows == 0) 
{
  echo '<hr>';
  echo '<div class="alert alert-danger">Invalid Username or Password</div>';
  echo '<hr>';
} 
else
{
//$sql = mysqli_query($link,"UPDATE user SET Signal='On' WHERE Email = '$email'") or die(mysqli_error($link));
echo '<hr>';
echo '<div class="alert alert-success">You have Successfully Login</div>';

session_start();
$_SESSION['tid'] = $row['admin_id'];
echo "<script>window.location='loader.php?tid=".$_SESSION['tid']."';</script>";												
}							
}

?>
                  </form>
				</div>
                </div>
              
                <div class="widget-foot">
                  Not Registred? <a href="#">Register here</a>
                </div>
            </div>  
      </div>
    </div>
  </div> 
</div>
	
		

<!-- JS -->
<script src="js/jquery.js"></script>
<script src="js/bootstrap.js"></script>
</body>
</html>