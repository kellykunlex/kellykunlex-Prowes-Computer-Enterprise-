<?php
include("config/session.php");
?>
<?php include "head.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
  	<!-- Main bar -->
  	<div class="mainbar">
      
	    <!-- Page heading -->
	    <div class="page-head">
        <!-- Page heading -->
	        <h2 class="pull-left">Dashboard 
			</h2>


			<!-- Breadcrumb -->
			<div class="bread-crumb pull-right">
			  <a href="dashboard.php"><i class="icon-home"></i> Home</a> 
			  <!-- Divider -->
			  <span class="divider">/</span> 
			  <a href="#" class="bread-current">Dashboard</a>
			</div>

			<div class="clearfix"></div>

	    </div>
	    <!-- Page heading ends -->
		
		
	<!-- Matter -->

	    <div class="matter">
        <div class="container">

          <!-- Today status. jQuery Sparkline plugin used. -->

          <div class="row">
            <div class="col-md-12"> 
              <!-- List starts -->
              <ul class="today-datas">

                <!-- List #1 -->
                <li class="bred">
                  <!-- Graph -->
                  <div class="pull-left"><span id="todayspark1" class="spark"></span></div>
                  <!-- Text -->
                  <div class="datas-text pull-right"><span class="bold">12,000</span> Visitors/Day</div>

                  <div class="clearfix"></div>
                </li>

                <li class="bgreen">
                  <!-- Graph -->
                 <div class="pull-left"><span id="todayspark2" class="spark"></span><i class="icon-group"></i></div>
                  <!-- Text -->
                  <div class="datas-text pull-right"><span class="bold">30,000</span> Members</div>

                  <div class="clearfix"></div>
                </li>

                <li class="bviolet">
                  <!-- Graph -->
                  <div class="pull-left"><span id="todayspark3" class="spark"></span></div>
                  <!-- Text -->
                  <div class="datas-text pull-right"><span class="bold">$22,000</span> Total Profit</div>

                  <div class="clearfix"></div>
                </li> 
 
 
  <li class="bviolet">
                  <!-- Graph -->
                  <div class="pull-left"><span id="todayspark3" </span></div>
                  <!-- Text -->
                  <div class="datas-text pull-right"><span class="bold">$22,000</span> Total Profit</div>

                  <div class="clearfix"></div>
                </li> 
				
              </ul> 
            </div>
          </div>

          <!-- Today status ends -->

          <!-- Dashboard Graph starts -->

          <div class="row">
            <div class="col-md-8">

              <!-- Widget -->
              <div class="widget wlightblue">
                <!-- Widget head -->
                <div class="widget-head">
                  <div class="pull-left">Dashboard</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>             

                <!-- Widget content -->
                <div class="widget-content">
                  <div class="padd">

                    <!-- Bar chart (Blue color). jQuery Flot plugin used. -->
                    <div id="bar-chart"></div>


                  </div>
                </div>
                <!-- Widget ends -->

              </div>
            </div>

            <div class="col-md-4">

              <div class="widget wblue">

                <div class="widget-head">
                  <div class="pull-left">Today Status</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>             

                <div class="widget-content">
                  <div class="padd">

                    <!-- Visitors, pageview, bounce rate, etc., Sparklines plugin used -->
                    <ul class="current-status">
                      <li>
                        <span id="status1"></span> <span class="bold">Visits : 2000</span> <i class="icon-arrow-up green"></i>
                      </li>
                      <li>
                        <span id="status2"></span> <span class="bold">Unique Visitors : 1,345</span> <i class="icon-arrow-down red"></i>
                      </li>
                      <li>
                        <span id="status3"></span> <span class="bold">Pageviews : 2000</span> <i class="icon-arrow-up green"></i>
                      </li>
                      <li>
                        <span id="status4"></span> <span class="bold">Pages / Visit : 2000</span> <i class="icon-arrow-down red"></i>
                      </li>
                      <li>
                        <span id="status5"></span> <span class="bold">Avg. Visit Duration : 2000</span> <i class="icon-arrow-down red"></i>
                      </li>
                      <li>
                        <span id="status6"></span> <span class="bold">Bounce Rate : 2000</span> <i class="icon-arrow-up green"></i>
                      </li>   
                      <li>
                        <span id="status7"></span> <span class="bold">% New Visits : 2000</span> <i class="icon-arrow-up green"></i>
                      </li>                                                                                                            
                    </ul>

                  </div>
                </div>

              </div>

            </div>
          </div>
          <!-- Dashboard graph ends -->

		
		
		<!-- Server Status -->
            <div class="col-md-6">
              <div class="widget wlightblue">
                <!-- Widget title -->
                <div class="widget-head">
                  <div class="pull-left">Server Status</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                <div class="widget-content">
                  <!-- Widget content -->
                  
                  <table class="table  table-bordered ">
                    <tr>
                      <td>Domain</td>
                      <td>sitedomain.com</td>
                    </tr> 
                    <tr>
                      <td>IP Address</td>
                      <td>192.425.2.4</td>
                    </tr> 
                    <tr>
                      <td>Disk Space</td>
                      <td>600GB / 60000GB</td>
                    </tr> 
                    <tr>
                      <td>Bandwidth</td>
                      <td>1000GB / 2000GB</td>
                    </tr> 
                    <tr>
                      <td>PHP Version</td>
                      <td>5.1.1</td>
                    </tr> 
                    <tr>
                      <td>MySQL Databases</td>
                      <td>10</td>
                    </tr>                                                                                                     
                  </table>

                </div>
              </div>
</div>
		
		<!-------------Quick Post------------->
			<div class="col-md-6">
              <div class="widget wgreen">
                <div class="widget-head">
                  <div class="pull-left">Quick Post</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>  
                  <div class="clearfix"></div>
                </div>
                
                <div class="widget-content">
                  <div class="padd">
                    
                      <div class="form quick-post">
                                      <!-- Edit profile form (not working)-->
                                      <form class="form-horizontal" method="post">
                                          <!-- Title -->
										                                <?php
$query = mysqli_query($link, "SELECT * FROM quik") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center' class='alert alert-danger'>No Notification Yet!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$foot = $row['location'];
$email = $row['cont'];
?>
                                          <div class="form-group">
                                            <label class="control-label col-lg-3" for="title">From</label>
                                            <div class="col-lg-9"> 
                                              <input type="text" class="form-control" value="<?php echo $foot;?>"  name="fm" id="title" required>
                                            </div>
                                          </div>   
                                          <!-- Content -->
                                          <div class="form-group">
                                            <label class="control-label col-lg-3" for="content">Content</label>
                                            <div class="col-lg-9">
                                              <textarea class="form-control" name="cont" value="<?php echo $email;?>" id="content" required></textarea>
                                            </div>
                                          </div>                           
                                          <?php }} ?>
                                          <!-- Buttons -->
                                          <div class="form-group">
                                             <!-- Buttons -->
											 <div class="col-lg-offset-3 col-lg-9">
												<button type="submit" name="submit" class="btn btn-success">Publish</button>
												<button type="reset" class="btn btn-default">Reset</button>
											 </div>
                                          </div>
										  
										   <?php
                                if (isset($_POST['submit'])) 
								{
								$mail= mysqli_real_escape_string($link,$_POST['fm']);
                                $cont = mysqli_real_escape_string($link,$_POST['cont']);
					$insert = mysqli_query($link, "UPDATE quik SET location = '$mail', cont = '$cont'") or die (mysqli_error($link));
								if(!$insert)
								{
								echo "<script>alert('Notification not Set.....Please try again later!'); </script>";
								}
					else
					{
								echo "<script>alert('Notification Set Successfully!!'); </script>";
								echo "<script>window.location='dashboard.php'; </script>";
								}
								}
								?>
                                      </form>
                                    </div>
                  </div>
                </div>
    </div>
		



   <!-- Mainbar ends -->	    	
   <div class="clearfix"></div>

</div>
<!-- Content ends -->
<?php include "notification.php"; ?>
<?php include "script.php"; ?>
