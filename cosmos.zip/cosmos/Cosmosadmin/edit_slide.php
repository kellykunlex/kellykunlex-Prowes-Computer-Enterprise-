<?php include'config/session.php';?>
<?php include "head.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
<!-- Main bar -->
  	<div class="mainbar">
      
	    <!-- Page heading -->
	    <div class="page-head">
        <!-- Page heading -->
	      <h2 class="pull-left">Latest Work  Settings 
        </h2>


        <!-- Breadcrumb -->
        <div class="bread-crumb pull-right">
          <a href="dashboard.php?id=<?php echo $_SESSION['tid']; ?>"><i class="icon-home"></i> Home</a> 
          <!-- Divider -->
          <span class="divider">/</span> 
          <a href="#" class="bread-current">Latest Work Settings </a>
        </div>

        <div class="clearfix"></div>

	    </div>
	    <!-- Page heading ends -->
		
	<!-- Page Content Start Here -->	
	<!-- Matter -->

	    <div class="matter">
        <div class="container">

          <div class="row">
				<div class="col-md-12">
   				 <div class="widget wgreen">             
                <div class="widget-head">
                  <div class="pull-left">Change Latest Work Images and Content</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                <div class="widget-content">
                  <div class="padd">

                    <h6>Input Your Projects DetailsChange Latest Work Images and Content <h6/>
                    <!-- Form starts.  -->
		<?php 
			$sidm= $_GET['lt_id'];
			$call = mysqli_query($link, "SELECT * FROM lt_work WHERE lt_id = '$sidm'") or die (mysqli_error($link));
			while($row = mysqli_fetch_array($call))
			{
			?>
                     <form class="form-horizontal" enctype="multipart/form-data" method="post" role="form">  
                                <div class="form-group">
                                  <label class="col-lg-2 control-label">Image Hover</label>
                                  <div class="col-lg-8">
                                    <input type="hidden" name="lt" class="form-control" value="<?php echo $row ['lt_id']; ?>" placeholder="Image Hover" required>
									<input type="text" name="title" class="form-control" value="<?php echo $row ['img_hover']; ?>" placeholder="Input Box" required>
                                  </div>
                                </div>
                                
                                <div class="form-group">
                                  <label class="col-lg-4 control-label">Title</label>
                                  <div class="col-lg-8">
                                    <input type="text" name="cat" class="form-control" value="<?php echo $row ['title']; ?>" placeholder="Title">
                                  </div>
                                </div>
								
                            
                                <div class="form-group">
                                  <label class="col-lg-4 control-label">Description</label>
                                  <div class="col-lg-8">
                                    <textarea class="form-control" name="abstrt" value="<?php echo $row ['content']; ?>" required></textarea>
                                  </div>
                                </div>                                  
                                
								<div class="form-group">
                                  <label class="col-lg-4 control-label">Upload Project Image</label>
                                  <div class="col-lg-8">
                                    <input type="file" class="form-control" name="image" onChange="readURL(this);"  required>
									<br />
									<img id="blah" src="img/<?php echo $row ['image']; ?>" alt="Preview Image Here" height="100" width="150"/>
                                  </div>
                                </div>
								
                                    <hr />
                                <div class="form-group">
                                  <div class="col-lg-offset-1 col-lg-9">
                                    <button type="submit" name="submit" class="btn btn-default">Set Latest Work </button>
                                  </div>
                                </div>
								 <?php 
								 }
								 ?> 
                    </form>
					<?php
                                if (isset($_POST['submit'])) 
								{
								$idt= mysqli_real_escape_string($link,$_POST['lt']);
								$title= mysqli_real_escape_string($link,$_POST['title']);
                                $cat = mysqli_real_escape_string($link,$_POST['cat']);
								$abstrt = mysqli_real_escape_string($link,$_POST['abstrt']);
								//image
                                $image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
                                $image_name = addslashes($_FILES['image']['name']);
                                $image_size = getimagesize($_FILES['image']['tmp_name']);
//
                                move_uploaded_file($_FILES["image"]["tmp_name"], "img/" . $_FILES["image"]["name"]);
                                $location = "img/" . $_FILES["image"]["name"];
								
								mysqli_query($link, "UPDATE lt_work SET img_hover = '$title', title = '$cat', content = '$abstrt', image = '$location' WHERE lt_id = '$idt' ") 							or die (mysqli_error($link));
								echo "<script>alert('Update Successfully!!'); </script>";
								}
								?>
                  </div>
                </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
              </div>  

            </div>

          </div>

        </div>
		  </div>

		<!-- Matter ends -->

    </div>

   <!-- Mainbar ends -->	    	
   <div class="clearfix"></div>

</div>
<!-- Content ends -->
<?php include "notification.php"; ?>
<?php include "script.php"; ?>
<script type="text/javascript">
        function readURL(input) {
            if (input.files && input.files[0]) {
                var reader = new FileReader();

                reader.onload = function (e) {
                    $('#blah').attr('src', e.target.result);
                }

                reader.readAsDataURL(input.files[0]);
            }
        }
    </script>