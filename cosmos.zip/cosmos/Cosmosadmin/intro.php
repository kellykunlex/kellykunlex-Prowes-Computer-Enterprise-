<?php include "head.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
<!-- Main bar -->
  	<div class="mainbar">
      
	    <!-- Page heading -->
	    <div class="page-head">
        <!-- Page heading -->
	      <h2 class="pull-left">Index Settings 
        </h2>


        <!-- Breadcrumb -->
        <div class="bread-crumb pull-right">
          <a href="dashboard.php?id=<?php echo $_SESSION['tid']; ?>"><i class="icon-home"></i> Home</a> 
          <!-- Divider -->
          <span class="divider">/</span> 
          <a href="#" class="bread-current">Index Settings </a>
        </div>

        <div class="clearfix"></div>

	    </div>
	    <!-- Page heading ends -->
		
	<!-- Page Content Start Here -->	
		
		
		<!-- Matter -->

	    <div class="matter">
        <div class="container">

          <div class="row">

            <div class="col-md-12">


              <div class="widget wgreen">
                
                <div class="widget-head">
                  <div class="pull-left">Index Settings</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                <div class="widget-content">
                  <div class="padd">

                    <h6>Index Settings Input Boxs</h6>
                    <hr />
                    <!-- Form starts.  -->
                     <form class="form-horizontal" method="post" role="form">
					  <?php
$query = mysqli_query($link, "SELECT * FROM intro") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center' class='alert alert-danger'>No Introduction Set !......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$title = $row['title'];
$cont = $row['content'];
?>
                              
                                <div class="form-group">
                                  <label class="col-lg-4 control-label">Title</label>
                                  <div class="col-lg-8">
                                    <input type="text" name="title" value="<?php echo $title;?>"class="form-control" placeholder="Title" required>
                                  </div>
                                </div>
                                
									<div class="form-group">
                                  <label class="col-lg-4 control-label">Content</label>
                                  <div class="col-lg-8">
                                    <textarea class="form-control"value ="<?php echo $cont;?>" name="content" required></textarea>
                                  </div>
                                </div>                                 
                                <?php }} ?>
                                    <hr />
                                <div class="form-group">
                                  <div class="col-lg-offset-1 col-lg-9">
                                    <button type="submit" name="submit"class="btn btn-primary">Save</button>
                                  </div>
                                </div>
								<?php include "config/connect.php"; ?>
								<?php 
								if (isset($_POST['submit'])) 
								{
								$title = mysqli_real_escape_string($link,$_POST['title']);
								$content = mysqli_real_escape_string($link, $_POST['content']);
								$insert = mysqli_query($link, "UPDATE intro SET title = '$title',content = '$content' ") or die (mysqli_error($link));
								if(!$insert)
								{
								echo "<script>alert('Introduction not inserted.....Please try again later!'); </script>";
								}
								else{
								echo "<script>alert('Introduction Added Successfully!!'); </script>";
								echo '<script>window.location="dashboard.php"; </script>';
								}
								}
								?>
								
                              </form>
                  </div>
                </div>	
				</div>
		<!-- Page Content End Here -->
		<div class="widget wviolet">
                <div class="widget-head">
                  <div class="pull-left">All Settings and Tables</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                  <div class="widget-content">

                    <table class="table table-bordered ">
                      <thead>
                        <tr>
                          <th>Title</th>
                          <th>Content</th>
                          <th>Control</th>
                        </tr>
                      </thead>
                      <tbody>
<?php include "config/connect.php"; ?>  
<?php
$query = mysqli_query($link, "SELECT * FROM intro ") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center'>You have no Introduction Test!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$idm = $row['title'];
$tid = $row['content'];
?> 
                        <tr>
						   <td><?php echo $idm ?></td>
						  <td><?php echo $tid; ?></td>
                          <td>
                         <a href="#c<?php echo $idm; ?>"> <button class="btn btn-sm btn-danger" data-target= "#c<?php echo $idm; ?>" data-toggle="modal" data-toggle="tooltip"><i class="icon-remove"></i> </button>
                          </td>
                        </tr>                                                           
<?php }} ?>  
                      </tbody>
                    </table>


                  </div>
                    <div class="widget-foot">
                      <div class="clearfix"></div> 
                    </div>
               		</div>
              		</div>
          			</div>
		<!-- Mainbar ends -->	    	
   <div class="clearfix"></div>

</div>
<!-- Content ends -->
<?php include "notification.php"; ?>
<?php include "script.php"; ?>
<?php
$query = mysqli_query($link, "SELECT * FROM intro ") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center'>You have no Introduction Test!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$idm = $row['title'];
$tid = $row['content'];
?> 
<div id="c<?php echo $idm; ?>" class="modal fade" tabindex="-1" role="dialog" aria-labelledby="myModalLabel" aria-hidden="true">
					<div class="modal-dialog">
					  <div class="modal-content">
                      <div class="modal-header">
                        <button type="button" class="close" data-dismiss="modal" aria-hidden="true">�</button>
                        <h4 class="modal-title">Delete Testimony</h4>
                      </div>
                      <div class="modal-body">
                        <p>Are you Sure you want to delete Testimony</p>
                      </div>
                      <div class="modal-footer">
					  <a href="delete.php?id=<?php echo $idm; ?>&&idm=<?php echo $tid; ?>" class="btn btn-danger"><i class="fa fa-trash"></i>&nbsp;Yes</a>
                        <button type="button" class="btn btn-default" data-dismiss="modal" aria-hidden="true">No</button>
                      </div>
                    </div>
					</div>
					</div>
                  </div>
                </div>
                  <div class="widget-foot">
                    <!-- Footer goes here -->
                  </div>
              </div>  

            </div>
			<?php }} ?>