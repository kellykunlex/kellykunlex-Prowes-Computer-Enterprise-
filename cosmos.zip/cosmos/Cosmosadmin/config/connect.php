<?php
$link = mysqli_connect("localhost","root","","cosmos") or die ("Unable to connect to Database");
?>

<?php
/*$server= "localhost";
$username= "root";
$password= "";
$database= "prowess";
$con = mysql_connect($server, $username, $password) or die("unable to connect to server");
$dbcon = mysql_select_db($database, $con) or die ("unable to connect db name");
*/?>