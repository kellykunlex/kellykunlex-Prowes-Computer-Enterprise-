<?php include "head.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
<!-- Main bar -->
  	<div class="mainbar">
      
	    <!-- Page heading -->
	    <div class="page-head">
        <!-- Page heading -->
	      <h2 class="pull-left">Settings and Tables 
        </h2>


        <!-- Breadcrumb -->
        <div class="bread-crumb pull-right">
          <a href="dashboard.php?id=<?php echo $_SESSION['tid']; ?>"><i class="icon-home"></i> Home</a> 
          <!-- Divider -->
          <span class="divider">/</span> 
          <a href="#" class="bread-current">Settings and Tables </a>
        </div>

        <div class="clearfix"></div>

	    </div>
	    <!-- Page heading ends -->

 <!-- Matter -->

	    <div class="matter">
        <div class="container">

          <div class="row">

            <div class="col-md-12">

                	<div class="widget wred">
                	<div class="widget-head">
                  	<div class="pull-left">All Settings and Tables</div>
                  	<div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                  <div class="widget-content">
                    <table class="table table-bordered ">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Location</th>
                          <th>Age</th>
                          <th>Education</th>
                        </tr>
                      </thead>
                      <tbody>
					  <?php include "config/connect.php"; ?>  
<?php
$query = mysqli_query($link, "SELECT test_id,name,email,user,test FROM test ORDER BY test_id DESC") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center'>You have no registered Testimony!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$idm = $row['test_id'];
$tid = $row['name'];
$name = $row['email'];
$email = $row['user'];
$phone = $row['test'];
?> 
                        <tr>
                          <td>1</td>
                          <td>Ashok</td>
                          <td>India</td>
                          <td>23</td>
                          <td>
                         <a href="#c<?php echo $idm; ?>"> <button class="btn btn-sm btn-danger" data-target= "#c<?php echo $idm; ?>" data-toggle="modal" data-toggle="tooltip"><i class="icon-remove"></i> </button>
                         <a href="#d<?php echo $tid; ?>"> <button class="btn btn-sm btn-primary" data-target= "#d<?php echo $tid; ?>" data-toggle="modal" data-toggle="tooltip"><i class="icon-pencil"></i> </button></td>
                        </tr>  
						<?php }} ?>                                                                        
                      </tbody>
                    </table>

                  		</div>
                    	<div class="widget-foot">                   
                      	<div class="clearfix"></div> 
                    	</div>
                		</div>



                <div class="widget wviolet">
                <div class="widget-head">
                  <div class="pull-left">All Settings and Tables</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                  <div class="widget-content">

                    <table class="table table-bordered ">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Location</th>
                          <th>Date</th>
                          <th>Type</th>
                          <th>Status</th>
                          <th>Control</th>
                        </tr>
                      </thead>
                      <tbody>

                        <tr>
                          <td>1</td>
                          <td>Ravi Kumar</td>
                          <td>India</td>
                          <td>23/12/2012</td>
                          <td>Paid</td>
                          <td><span class="label label-success">Active</span></td>
                          <td>

                              <button class="btn btn-sm btn-success"><i class="icon-ok"></i> </button>
                              <button class="btn btn-sm btn-warning"><i class="icon-pencil"></i> </button>
                              <button class="btn btn-sm btn-danger"><i class="icon-remove"></i> </button>
                          
                          </td>
                        </tr>                                                           

                      </tbody>
                    </table>


                  </div>
                    <div class="widget-foot">
                      <div class="clearfix"></div> 
                    </div>
               		</div>
              		</div>
          			</div>

          		<div class="row">
            	<div class="col-md-6">
                <div class="widget worange">
                <div class="widget-head">
                  <div class="pull-left">All Settings and Tables</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                  <div class="widget-content">

                    <table class="table table-bordered ">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Location</th>
                          <th>Type</th>
                          <th>Status</th>
                        </tr>
                      </thead>
                      <tbody>

                        <tr>
                          <td>1</td>
                          <td>Ravi Kumar</td>
                          <td>India</td>
                          <td>Paid</td>
                          <td><span class="label label-success">Active</span></td>

                        </tr>                                                            

                      </tbody>
                    </table>
                 	 </div>

                    <div class="widget-foot">                      
                      <div class="clearfix"></div> 
                    </div>
                	</div>
              		</div>

             	 <div class="col-md-6">
                <div class="widget wlightblue">
                <div class="widget-head">
                  <div class="pull-left">All Settings and Tables</div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>

                  <div class="widget-content">
                    <table class="table  table-bordered ">
                      <thead>
                        <tr>
                          <th>#</th>
                          <th>Name</th>
                          <th>Location</th>
                          <th>Date</th>
                          <th>Type</th>
                        </tr>
                      </thead>
                      <tbody>

                        <tr>
                          <td>1</td>
                          <td>Ravi Kumar</td>
                          <td>India</td>
                          <td>23/12/2012</td>
                          <td>Paid</td>
                        </tr>
                     </tbody>
                    </table>

                  </div>

                    <div class="widget-foot">
                      <div class="clearfix"></div> 
                    </div>                  
                	</div>
              		</div>

</div>
</div>
</div>

		<!-- Matter ends -->

</div>

   <!-- Mainbar ends -->	    	
   <div class="clearfix"></div>

</div>
<!-- Content ends -->
<!-- Content ends -->
<?php include "notification.php"; ?>
<?php include "script.php"; ?>
<!------- Modal Forms For the Update Start Herer----------->