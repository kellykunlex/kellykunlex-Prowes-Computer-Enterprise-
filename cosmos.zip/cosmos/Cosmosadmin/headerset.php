<?php include "config/connect.php"; ?>  
<?php
if(isset($_POST['upload']))
{
$image = addslashes(file_get_contents($_FILES['image']['tmp_name']));
$image_name = addslashes($_FILES['image']['name']);
$image_size = getimagesize($_FILES['image']['tmp_name']);

if($image_name == "")
{
echo '<script>alert("Please you have to upload Image!..."); </script>';
echo '<script>window.location="headerset.php"; </script>';
}
else{
//
move_uploaded_file($_FILES["image"]["tmp_name"], "img/".$_FILES["image"]["name"]);

$location = "img/".$_FILES['image']['name'];

$insert = mysqli_query($link, "INSERT INTO headerset(banaid,banner) VALUES('','$location')") or die (mysqli_error($link));
if(!$insert)
{
echo "<script>alert('Unable to Insert Banner......Please try again later!!!');</script>";
echo "<script>window.location='headerset.php'; </script>";
}
else{
echo "<script>alert('Banner Added Succefully!!!');</script>";
echo "<script>window.location='dashboard.php'; </script>";
}
}
}
?>
<?php include "head.php"; ?>
<?php include "navigation.php"; ?>
<?php include "sidebar.php"; ?>
<!-- Main bar -->
  	<div class="mainbar">
      
	    <!-- Page heading -->
	    <div class="page-head">
        <!-- Page heading -->
	      <h2 class="pull-left">Header Settings 
        </h2>


        <!-- Breadcrumb -->
        <div class="bread-crumb pull-right">
          <a href="index.php"><i class="icon-home"></i> Home</a> 
          <!-- Divider -->
          <span class="divider">/</span> 
          <a href="#" class="bread-current">Set Your Header </a>
        </div>

        <div class="clearfix"></div>

	    </div>
	    <!-- Page heading ends -->
		 <!-- Matter -->

	    <div class="matter">
        <div class="container">

          <div class="row">

            <div class="col-md-12">
<div class="widget wred">

                <div class="widget-head">
                  <div class="pull-left">Header </div>
                  <div class="widget-icons pull-right">
                    <a href="#" class="wminimize"><i class="icon-chevron-up"></i></a> 
                    <a href="#" class="wclose"><i class="icon-remove"></i></a>
                  </div>
                  <div class="clearfix"></div>
                </div>


                    <ul id="myTab" class="nav nav-tabs">
                      <li class="active"><a href="#home" data-toggle="tab">Home</a></li>
                      <li><a href="#profile" data-toggle="tab">Profile</a></li>
                      <li><a href="#cont" data-toggle="tab">Content</a></li>
                    </ul>
                    <div id="myTabContent" class="tab-content">
                      <div class="tab-pane fade in active" id="home">
                        <div class="box-body">
                  <div class="widget-content">

                      
                      </div>
                      <div class="tab-pane fade" id="profile">
                        <<div class="box-body">
<div align="left">	  
<a href="#k"> <button type="button" data-target= "#k" class="btn btn-success btn-flat" data-toggle="modal" data-toggle="tooltip"><i class="fa fa-plus">&nbsp;Add Banner</i></button></a>
</div>		
<br/>
                  <div class="widget-content">

                     <table id="example1" class="table table-bordered table-striped">
                  <thead>
                <tr>
                  <th>ID</th>
				  <th>Banner</th>
				  <th>Operation</th>
                </tr>
				</thead>
                <tbody>  
<?php
$query = mysqli_query($link, "SELECT logoid,logo FROM logo") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center' class='alert alert-danger'>No Logo Yet!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$logoid = $row['logoid'];
$logo = $row['logo'];
?>

                <tr>
				  <td><?php echo $logoid; ?></td>
				  <td><a href="#u<?php echo $logoid; ?>"> <button type="button" data-target= "#t<?php echo $logoid; ?>" class="btn btn-info" data-toggle="modal" data-toggle="tooltip"><i class="fa fa-search-plus"></i><img src="<?php echo $logo; ?>" width="50" height="50"></td>
				  <th><a href="delete_banner.php?id=<?php echo $logoid; ?>" class="btn btn-danger"><i class="fa fa-gears"></i>&nbsp;Delete</a></th>
                </tr>
<?php
}
}
?> 
          		</tbody>
                </table> 
                      </div>
                      <div class="tab-pane fade" id="cont">
                        <div class="box-body">
<div align="left">	  
<a href="#k"> <button type="button" data-target= "#k" class="btn btn-success btn-flat" data-toggle="modal" data-toggle="tooltip"><i class="fa fa-plus">&nbsp;Add Banner</i></button></a>
</div>		
<br/>
                  <div class="widget-content">

                     <table id="example1" class="table table-bordered table-striped">
                  <thead>
                <tr>
                  <th>ID</th>
				  <th>Banner</th>
				  <th>Operation</th>
                </tr>
				</thead>
                <tbody>  
<?php
$query = mysqli_query($link, "SELECT favid,favicon FROM favi") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center' class='alert alert-danger'>No Banner Yet!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$favid = $row['favid'];
$favicon = $row['favicon'];
?>

                <tr>
				  <td><?php echo $favid; ?></td>
				  <td><a href="#v<?php echo $favid; ?>"> <button type="button" data-target= "#t<?php echo $favid; ?>" class="btn btn-info" data-toggle="modal" data-toggle="tooltip"><i class="fa fa-search-plus"></i><img src="<?php echo $favicon; ?>" width="50" height="50"></td>
				  <th><a href="delete_banner.php?id=<?php echo $favid; ?>" class="btn btn-danger"><i class="fa fa-gears"></i>&nbsp;Delete</a></th>
                </tr>
<?php
}
}
?> 
          		</tbody>
                </table> 
                      </div>
                    </div>

                </div>


              </div>

          </div>
		    <!-- Mainbar ends -->	    	
   <div class="clearfix"></div>

</div>
<!-- Content ends -->
<?php include "notification.php"; ?>
<?php include "script.php"; ?>
<?php
$query = mysqli_query($link, "SELECT banaid,banner FROM headerset") or die (mysqli_error($link));
while($row = mysqli_fetch_array($query)){
$banaid = $row['banaid'];
$bannar = $row['banner'];
?>
 

 <div class="modal fade modal-info" id="t<?php echo $banaid; ?>" role="dialog">
			<div class="modal-dialog">
    
      <!-- Modal content-->
	  		<div class="modal-content">
        	<div class="modal-header">
           <button type="button" class="close" data-dismiss="modal" style=" color:#FFFFFF">&times;</button>
           <strong> <h4 class="modal-title" style="color:#FFFFFF"align="center">PREVIEW IMAGE</h4></strong>
           </div>
        		
				<div class="modal-body">
<div align="center">	

<img src="<?php echo $bannar; ?>">
</div>
<hr>
		        <button type="button" class="btn btn-danger btn-outline btn-flat" data-dismiss="modal"><i class="fa fa-minus"></i>&nbsp;Close</button>
      </div>
     </div>

   </div>
	</div> 
<!-- Modal content-->
	  		<div class="modal-content">
        	<div class="modal-header">
           <button type="button" class="close" data-dismiss="modal" style=" color:#FFFFFF">&times;</button>
           <strong> <h4 class="modal-title" style="color:#FFFFFF"align="center">UPLOAD BANNER!!!</h4></strong>
           </div>
        		
				<div class="modal-body">
					<span style="color:#FF0000"><h3>Please Make sure you upload bannar with image size: 640 x 420 </h3></span>
				<div class="table-responsive">
				
				<form action="" method="post" enctype="multipart/form-data">
				 <div class="form-group">
                  <label for="" class="col-sm-2 control-label" align="center">Browse Image <span style="color:#FF0000">png format only</span></label>
				<div class="col-sm-10">
				
  		  			 <input type="file" name="image" onChange="readURL(this);" /required>
       				 <img id="blah" src="#" alt="your image"/>
				</div>
				
				</div>
				
			
<hr>
<button type="submit" class="btn btn-success btn-flat" name="upload"><i class="fa fa-upload">Upload</i></button>
		        <button type="button" class="btn btn-danger btn-outline btn-flat" data-dismiss="modal"><i class="fa fa-minus"></i>&nbsp;No</button>
		        
		        
		        </form>
		        </div>
      </div>
     </div>

   </div>
	</div> 