<?php
include("config/connect.php");
$id = $_GET['id'];
$idm = $_GET['idm'];
$duser = mysqli_query($link, "DELETE FROM test WHERE test_id = '$idm'") or die (mysqli_error($link));
$dbnk = mysqli_query($link, "DELETE FROM client WHERE cl_id = '$idm'") or die (mysqli_error($link));
$db = mysqli_query($link, "DELETE FROM slide WHERE slide_id = '$id'") or die (mysqli_error($link));
if(!($duser && $dbnk && $db))
{
echo "<script>alert('Unable to delete records!!!.......please try again later');</script>";
}
else{
echo "<script>alert('Delete Operation is successfully!!!');</script>";
echo "<script>window.location='dashboard.php';</script>";
}
?>

		