<!-- banner -->
	<div class="banner-silder">
			 <div class="banner">
					<ul>
					</ul>
				  <ol>
				  </ol>
				  <i class="left"></i><i class="right"></i>
				  <div class="banner_wthree_agile_info">
				     <section class="rw-wrapper">
						<div class="rw-sentence">
						<h5>
						<span>The Finest Quality </span>
							<br />
							<span>of Construction And</span>
					
							<div class="rw-words rw-words-1">
					
								<span></span>
										<?php
$query = mysqli_query($link, "SELECT * FROM slide") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center' class='alert alert-danger'>No Article to Set !......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$title = $row['title'];
?>
								<span><?php echo $title;?></span>
															<?php }} ?>
								</h5>
							</div>

						</div>
			         </section>
					 <div class="wthree_more">
					  <a href="single.html" data-toggle="modal" data-target="#myModal" class="button--wayra button--border-thick button--text-upper button--size-s">Learn More</a>
				     </div>
					
						<div class="social_list_w3ls">
							<a href="#" class="w3_agile_facebook_agile"><span class="fa fa-facebook" aria-hidden="true"></span></a>
							<a href="#" class="agile_twitter_agile"><span class="fa fa-twitter" aria-hidden="true"></span></a>
							<a href="#" class="w3_agile_dribble_agile"><span class="fa fa-dribbble" aria-hidden="true"></span></a>
							<a href="#" class="w3_agile_vimeo_agile"><span class="fa fa-vimeo" aria-hidden="true"></span></a>
						</div>
					

				  </div>
		     </div>
		
	</div>
<!-- //banner -->