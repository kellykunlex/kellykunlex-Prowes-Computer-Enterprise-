<?php require_once('connect.php'); ?>
<!-- bootstrap-pop-up -->
	<div class="modal video-modal fade" id="myModal" tabindex="-1" role="dialog" aria-labelledby="myModal">
		<div class="modal-dialog" role="document">
			<div class="modal-content">
				<div class="modal-header">
					Cosmospark Engineering Limited
					<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>						
				</div>
				<section>
					<div class="modal-body">
						<img src="images/g4.jpg" alt=" " class="img-responsive" />
						<p>Career
    Cosmospark Engineering Limited relies on a national distribution network comprised of knowledgeable and experienced agents.
					</div>
				</section>
			</div>
		</div>
	</div>
		<div class="modal fade" id="myModal2" tabindex="-1" role="dialog">
														<div class="modal-dialog">
														<!-- Modal content-->
															<div class="modal-content">
																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal">&times;</button>
																	
																	<div class="signin-form profile">
																	<h3 class="agileinfo_sign">Sign In</h3>	
																			<div class="login-form">
																				<form action="#" method="post">
																					<input type="text" name="email" placeholder="E-mail" required="">
																					<input type="password" name="password" placeholder="Password" required="">
																					<div class="tp">
																						<input type="submit" name="submit" value="Sign In">
																					</div>
																					
																				</form>
																			</div>
																			<div class="login-social-grids">
																				<ul>
																					<li><a href="#"><i class="fa fa-facebook"></i></a></li>
																					<li><a href="#"><i class="fa fa-twitter"></i></a></li>
																					<li><a href="#"><i class="fa fa-rss"></i></a></li>
																				</ul>
																			</div>
																			<p><a href="#" data-toggle="modal" data-target="#myModal3" > Don't have an account?</a></p>
																		</div>
																</div>
															</div>
														</div>
													</div>
													<!-- //Modal1 -->	
													<!-- Modal2 -->
													<div class="modal fade" id="myModal3" tabindex="-1" role="dialog">
														<div class="modal-dialog">
														<!-- Modal content-->
															<div class="modal-content">
																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal">&times;</button>
																	
																	<div class="signin-form profile">
																	<h3 class="agileinfo_sign">Sign Up</h3>	
																			<div class="login-form">
																				<form action="#" method="post">
																				   <input type="text" name="name" placeholder="Representative Name" required="">
																					<input type="email" name="email" placeholder="Email" required="">
																					<input type="text" name="mob" placeholder="Mobile" required="">
																					<input type="text" name="cname" placeholder="Comapny Name" required="">
																					<input type="text" name="state" placeholder="State" required="">
																					<input type="text" name="cadd" placeholder="Company Address" required="">
																					<input type="submit" name="submit" value="Sign Up">
																					
																					
																					<?php  
								if(isset($_POST['submit']))
								{
								$name = mysqli_real_escape_string($link, $_POST['name']);
								$email = mysqli_real_escape_string($link, $_POST['email']);
								$mob = mysqli_real_escape_string($link, $_POST['mob']);
								$cname = mysqli_real_escape_string($link, $_POST['cname']);
								$state = mysqli_real_escape_string($link, $_POST['state']);
								$cadd = mysqli_real_escape_string($link, $_POST['cadd']);
								$inserts = mysqli_query($link, "INSERT INTO newsletter(comp_name,email,news) VALUES('$cname','$email','')") or die (mysqli_error($link));
								$insert = mysqli_query($link, "INSERT INTO client(cl_id,name,email,mobile,comp_name,state,address) VALUES('','$name','$email','$mob','$cname',$cname','$cadd')") or die (mysqli_error($link));
								if(!$insert && $inserts)
								{
								echo "<script>alert('Record Not Added.....Please try again later!'); </script>";
								}
								else{
								echo "<script>alert('Thank You for Joinning Us. God Bless You'); </script>";
								}
								}
								?>
																				</form>
																			</div>
																			<p><a href="#"> By clicking register, I agree to your terms</a></p>
																		</div>
																</div>
															</div>
														</div>
													</div>
													<!-- //Modal2 -->	
													<!-- Modal4 -->
													<div class="modal fade" id="myModal4" tabindex="-1" role="dialog">
														<div class="modal-dialog">
														<!-- Modal content-->
															<div class="modal-content">
																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal">&times;</button>
																	
																	<div class="signin-form profile">
																	<h3 class="agileinfo_sign">Give a Testimony</h3>	
																			<div class="agileinfo_mail_grids">
																				<form class="form"  method="post" enctype="multipart/form-data">
																				   <input type="text" name="name" placeholder="Fullname" required="">
																					<input type="email" name="email" placeholder="Email" required="">
																					<textarea name="test" placeholder="Your Testimony Here..." required=""></textarea>
																					<input type="submit"name="submit" value="Send">
								<?php 
								if(isset($_POST['submit']))
								{
								$name = mysqli_real_escape_string($link, $_POST['name']);
								$email = mysqli_real_escape_string($link, $_POST['email']);
								$test = mysqli_real_escape_string($link, $_POST['test']);
								$insert = mysqli_query($link, "INSERT INTO test(test_id,name,email,user,test) VALUES('','$name','$email','Client','$test')") or die (mysqli_error($link));
								if(!$insert)
								{
								echo "<script>alert('Testimony Not Added.....Please try again later!'); </script>";
								}
								else{
								echo "<script>alert('Added Successfully!!'); </script>";
								}
								}
								?>
																					
																				</form>
																			</div>
																		</div>
																</div>
															</div>
														</div>
													</div>
													<!-- //Modal4 -->	
													
													<!-- Modal6 -->
													<div class="modal fade" id="myModal6" tabindex="-1" role="dialog">
														<div class="modal-dialog">
														<!-- Modal content-->
															<div class="modal-content">
																<div class="modal-header">
																	<button type="button" class="close" data-dismiss="modal">&times;</button>
																	
																	<div class="signin-form profile">
																	<h3 class="agileinfo_sign">We are just a Call Away</h3>	
																			<li><i class="fa fa-phone" aria-hidden="true"><p align="justify">07082933742, 08157485830</p></li></i>
												<li><i class="fa fa-envelope" aria-hidden="true"><p align="justify">    leadadmins@cosmosparks.com </p></li></i>
												<li><i class="fa fa-envelope" aria-hidden="true"><p align="justify">   infosparks@cosmosparks.com </p></li></i>

																			</div>
																		</div>
																</div>
															</div>
														</div>
													</div>
													<!-- //Modal6 -->	
<?php
$query = mysqli_query($link, "SELECT * FROM introcontent") or die (mysqli_error($link));
if(mysqli_num_rows($query)==0)
{
echo "<strong><p align='center' class='alert alert-danger'>No Banner Yet!......</p></strong>";
}
else{
while($row = mysqli_fetch_array($query)){
$banaid = $row['slide_id'];
$title = $row['title'];
$bannar = $row['descrip'];
$image = $row['slideimage'];
?>
 <div class="modal fade modal-info" id="t<?php echo $banaid; ?>" role="dialog">
			<div class="modal-dialog">
				<!-- Modal content-->
				<div class="modal-content">
			<div class="modal-header">
		<button type="button" class="close" data-dismiss="modal">&times;</button>
		<div class="signin-form profile">
			<h3 class="agileinfo_sign">Preview</h3>	
			<div class="login-form">	
				<img src="Cosmosadmin/<?php echo $image; ?>" height="200" width="300">
				</div>
				<p><?php echo $bannar; ?></p>
				<hr>
		        <button type="button" class="btn btn-danger btn-outline btn-flat" data-dismiss="modal"><i class="fa fa-minus"></i>&nbsp;Close</button>
      </div>
     </div>

   </div>
	</div> 
<?php } }?>

<!-- //bootstrap-pop-up -->