<?php
$link = mysqli_connect("localhost","root","","cosmos") or die("Unable to Connect to Database");
?>